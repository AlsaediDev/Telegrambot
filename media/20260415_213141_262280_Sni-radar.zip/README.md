# 🚀 SNI Radar

> 🔍 Intelligent SNI / TCP / Ping / CDN Scanner with Live Streaming UI  
> 🔍 اسکنر هوشمند SNI / TCP / پینگ / CDN با رابط گرافیکی زنده

---

## ✨ Features | ویژگی‌ها

- ⚡ Live Streaming Results (NDJSON)  
  ⚡ نمایش نتایج به صورت زنده

- 🧠 Smart SNI Detection  
  🧠 تشخیص هوشمند SNI

- 🌐 CDN Provider Identification  
  🌐 شناسایی ارائه دهنده CDN

- 📡 Ping + TCP Health Checks  
  📡 بررسی پینگ و اتصال TCP

- 🧵 Multi-threaded Scanning (UI: 1-100 threads)  
  🧵 اسکن چند نخی (در رابط: ۱ تا ۱۰۰ ترد)

- 🛑 Real-time Stop Control (/api/stop)  
  🛑 توقف آنی اسکن

- 🎯 CIDR Expansion with max_hosts limit  
  🎯 پشتیبانی از CIDR با محدودیت max_hosts

- 🎨 Modern Glassmorphism UI + Live Sorting  
  🎨 رابط کاربری مدرن گلس + مرتب سازی زنده

- 📊 Live Metrics Dashboard  
  📊 داشبورد آمار لحظه ای

- 💾 Auto-save JSON Results  
  💾 ذخیره خودکار نتایج JSON

- 📄 Export Successful Targets as TXT (UI button)  
  📄 خروجی TXT برای نتایج موفق

---

## 🧠 What is this? | این ابزار چیه؟

SNI Radar یک ابزار تحلیل شبکه است که این موارد را بررسی می کند:

- Domain / IP / CIDR
- TLS SNI usability
- CDN detection
- Network reachability

مناسب برای:

- تحلیل شبکه
- بررسی وضعیت CDN
- تست دسترس پذیری سرویس
- دیباگ مسیر ارتباطی

---

## ⚙️ Installation | نصب

```bash
pip install -r requirements.txt
```

---

## ▶️ Run | اجرا

```bash
python sni_web.py
```

سپس باز کن:

```text
http://127.0.0.1:10808
```

---

## 📥 Input Examples | مثال ورودی

```text
cloudflare.com
1.1.1.1
8.8.8.8
127.0.0.1/30
```

---

## 📊 Output | خروجی

نمونه ستون های جدول:

- Target
- IP
- Ping
- TCP / SNI
- Provider (CDN)
- Verdict

نمونه وضعیت ها:

- SNI-USABLE
- CDN-USABLE
- TCP+PING
- PING-ONLY
- TCP-ONLY
- DOWN

---

## 🧩 How It Works | نحوه کار

1. Resolve domain to IP
2. Expand CIDR targets (با max_hosts)
3. Ping test
4. TCP connectivity test
5. TLS SNI handshake test (برای دامنه)
6. CDN detection
7. Score and verdict
8. Stream live progress to UI

---

## 📁 Output Files | فایل خروجی

بعد از هر اسکن یک فایل JSON ذخیره می شود:

```text
sni_results_YYYYMMDD_HHMMSS.json
```

---

## 🛠️ Tech Stack

- Python
- Flask
- ThreadPoolExecutor
- Vanilla JavaScript

---

## 📡 API

### POST /api/scan

Request body:

```json
{
  "targets": ["example.com", "1.1.1.1"],
  "strict_ping": true,
  "max_hosts": 4096,
  "threads": 10
}
```

Response type:

- application/x-ndjson
- streamed events: init, progress, done

Example progress event:

```json
{
  "type": "progress",
  "result": {
    "target": "example.com",
    "ip": "93.184.216.34",
    "ping_ok": true,
    "tcp_ok": true,
    "sni_ok": true,
    "cdn": "NONE",
    "overall": "SNI-USABLE"
  },
  "stats": {
    "tcp_ping": 4,
    "ping_only": 1,
    "tcp_only": 0,
    "down": 2,
    "total": 10,
    "checked": 7
  }
}
```

### POST /api/stop

Stops the active scan job.

Response example:

```json
{
  "status": "stopping"
}
```

### GET /health

Health check endpoint.

---

## ⚠️ Disclaimer | هشدار

This project is for educational and authorized testing purposes only.

این ابزار را فقط روی سیستم ها و دامنه هایی استفاده کنید که مجوز بررسی آن ها را دارید.

---

## 👤 Author | سازنده

- Telegram: @itsthemoein

## 📢 Channel | کانال

- Telegram: @persiatmchannel

---

## ⭐ Support

اگر خوشت اومد:

- Star کن
- Fork کن
- ایده بده

---

Made with ❤️ by Moein
